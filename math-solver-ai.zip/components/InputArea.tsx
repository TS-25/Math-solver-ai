import React, { useState } from 'react';
import { LoadingSpinner } from './LoadingSpinner';
import type { Language } from '../App';

interface InputAreaProps {
  onSolve: (problem: string) => void;
  isLoading: boolean;
  language: Language;
}

export const InputArea: React.FC<InputAreaProps> = ({ onSolve, isLoading, language }) => {
  const [problem, setProblem] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSolve(problem);
  };
  
  const placeholderText = language === 'en' 
    ? "e.g., Find the derivative of x^3 * sin(x)" 
    : "যেমন, x^3 * sin(x) এর ডেরিভেটিভ খুঁজুন";
  
  const buttonText = language === 'en' ? 'Solve Problem' : 'সমাধান করুন';
  const solvingText = language === 'en' ? 'Solving...' : 'সমাধান হচ্ছে...';

  const labelText = language === 'en' 
    ? "Enter your math problem below" 
    : "আপনার গণিত সমস্যাটি নীচে লিখুন";

  return (
    <div className="bg-slate-800/50 rounded-xl shadow-lg border border-slate-700 overflow-hidden">
      <form onSubmit={handleSubmit}>
        <div className="p-4 sm:p-6">
           <label htmlFor="problem-input" className="block text-sm font-medium text-slate-400 mb-2">
            {labelText}
          </label>
          <textarea
            id="problem-input"
            value={problem}
            onChange={(e) => setProblem(e.target.value)}
            placeholder={placeholderText}
            className="w-full h-32 p-3 bg-slate-900 border border-slate-600 rounded-lg resize-y focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition duration-200 text-slate-200 placeholder-slate-500"
            disabled={isLoading}
          />
        </div>
        <div className="bg-slate-800 px-4 py-3 sm:px-6 flex justify-end">
          <button
            type="submit"
            disabled={isLoading || !problem.trim()}
            className="inline-flex items-center justify-center px-6 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 focus:ring-offset-slate-900 disabled:bg-slate-600 disabled:cursor-not-allowed transition-all duration-200"
          >
            {isLoading ? <><LoadingSpinner className="mr-2" /> {solvingText}</> : buttonText}
          </button>
        </div>
      </form>
    </div>
  );
};