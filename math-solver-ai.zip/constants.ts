export const GEMINI_MODEL = "gemini-2.5-flash-preview-04-17";

export const EXAMPLE_PROBLEMS_EN = [
  "Solve for x in the equation 2x^2 - 3x - 5 = 0",
  "What is the integral of sin(x) * cos(x) dx?",
  "Find the derivative of f(x) = (x^3 + 2x) / (x^2 - 1)",
  "If a triangle has sides of length 5, 12, and 13, is it a right-angled triangle?",
  "Calculate the limit of (x^2 - 4) / (x - 2) as x approaches 2",
];

export const EXAMPLE_PROBLEMS_BN = [
  "2x^2 - 3x - 5 = 0 সমীকরণে x এর মান নির্ণয় কর",
  "sin(x) * cos(x) dx এর ইন্টিগ্রাল কি?",
  "f(x) = (x^3 + 2x) / (x^2 - 1) এর ডেরিভেটিভ নির্ণয় কর",
  "যদি একটি ত্রিভুজের বাহুগুলোর দৈর্ঘ্য 5, 12, এবং 13 হয়, তবে এটি কি একটি সমকোণী ত্রিভুজ?",
  "x এর মান 2 এর কাছাকাছি হলে (x^2 - 4) / (x - 2) এর লিমিট গণনা কর",
];