import React from 'react';
import { EXAMPLE_PROBLEMS_EN, EXAMPLE_PROBLEMS_BN } from '../constants';
import type { Language } from '../App';

interface ExampleProblemsProps {
  onSelectProblem: (problem: string) => void;
  isLoading: boolean;
  language: Language;
}

export const ExampleProblems: React.FC<ExampleProblemsProps> = ({ onSelectProblem, isLoading, language }) => {
  const problems = language === 'en' ? EXAMPLE_PROBLEMS_EN : EXAMPLE_PROBLEMS_BN;
  const labelText = language === 'en' ? 'Or try an example:' : 'অথবা একটি উদাহরণ চেষ্টা করুন:';
  
  return (
    <div>
      <h3 className="text-center text-sm font-medium text-slate-400 mb-3">{labelText}</h3>
      <div className="flex flex-wrap justify-center gap-2">
        {problems.map((problem, index) => (
          <button
            key={index}
            onClick={() => onSelectProblem(problem)}
            disabled={isLoading}
            className="px-3 py-1.5 text-sm bg-slate-700/50 border border-slate-600 rounded-full text-slate-300 hover:bg-slate-700 hover:border-cyan-500/50 hover:text-cyan-300 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {problem}
          </button>
        ))}
      </div>
    </div>
  );
};