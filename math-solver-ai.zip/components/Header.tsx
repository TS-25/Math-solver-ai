import React from 'react';
import { MathIcon } from './icons/MathIcon';
import type { Language } from '../App';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
}

export const Header: React.FC<HeaderProps> = ({ language, onLanguageChange }) => {
  return (
    <header className="py-5 bg-slate-900/60 backdrop-blur-sm border-b border-slate-700/50 sticky top-0 z-10">
      <div className="container mx-auto px-4 flex items-center justify-center relative">
        <div className="flex items-center">
            <MathIcon className="w-8 h-8 mr-3 text-cyan-400" />
            <h1 className="text-3xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 animate-text-gradient">
            Math Solver AI
            </h1>
        </div>

        <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center space-x-1 p-1 bg-slate-800 rounded-full border border-slate-700">
            <button 
                onClick={() => onLanguageChange('en')} 
                className={`px-3 py-1 text-sm rounded-full transition-colors duration-200 ${language === 'en' ? 'bg-cyan-500 text-white' : 'text-slate-300 hover:bg-slate-700'}`}
                aria-pressed={language === 'en'}
            >
                EN
            </button>
            <button 
                onClick={() => onLanguageChange('bn')} 
                className={`px-3 py-1 text-sm rounded-full transition-colors duration-200 ${language === 'bn' ? 'bg-cyan-500 text-white' : 'text-slate-300 hover:bg-slate-700'}`}
                aria-pressed={language === 'bn'}
            >
                বাংলা
            </button>
        </div>
      </div>
    </header>
  );
};