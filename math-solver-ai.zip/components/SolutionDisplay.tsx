import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';
import type { Language } from '../App';

interface SolutionDisplayProps {
  solution: string;
  isLoading: boolean;
  error: string | null;
  problem: string;
  language: Language;
}

const FormattedSolution: React.FC<{ text: string }> = ({ text }) => {
    // A simple formatter to make the output more readable
    const formattedText = text
      .replace(/\*\*(.*?)\*\*/g, '<strong class="text-cyan-400 font-bold">$1</strong>')
      .replace(/`([^`]+)`/g, '<code class="bg-slate-700 text-emerald-300 rounded-md px-1.5 py-0.5 font-mono text-sm">$1</code>')
      .replace(/(\d+\.) (.*?)(?=\n\d+\.|\n\n|$)/gs, (match, num, content) => {
          return `<div class="flex items-start mt-3"><div class="flex-shrink-0 h-6 w-6 rounded-full bg-slate-700 text-cyan-400 flex items-center justify-center font-bold text-sm mr-3">${num.replace('.','')}</div><div class="flex-grow">${content.trim()}</div></div>`
      });


  return (
    <div className="prose prose-invert prose-slate max-w-none" dangerouslySetInnerHTML={{ __html: formattedText }} />
  );
};

export const SolutionDisplay: React.FC<SolutionDisplayProps> = ({ solution, isLoading, error, problem, language }) => {
  const renderContent = () => {
    const thinkingText = language === 'en' ? 'AI is thinking...' : 'AI ভাবছে...';
    const solvingText = language === 'en' ? 'Solving your problem:' : 'আপনার সমস্যার সমাধান করা হচ্ছে:';
    const solutionHeaderText = language === 'en' ? 'Solution' : 'সমাধান';
    const idleText = language === 'en' 
      ? "The solution will appear here once you solve a problem." 
      : "আপনি একটি সমস্যার সমাধান করলে এখানে সমাধানটি প্রদর্শিত হবে।";

    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center p-8 text-center">
          <LoadingSpinner className="h-8 w-8 text-cyan-400" />
          <p className="mt-4 text-lg font-medium text-slate-300">{thinkingText}</p>
          <p className="text-slate-400 mt-1">{solvingText} "{problem}"</p>
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="p-6 text-center bg-red-900/20 border border-red-500/30 rounded-lg">
          <h3 className="font-bold text-red-400">Error</h3>
          <p className="text-slate-300 mt-2">{error}</p>
        </div>
      );
    }

    if (solution) {
      return (
        <div className="p-6 space-y-4">
          <h2 className="text-2xl font-bold text-slate-100">{solutionHeaderText}</h2>
          <FormattedSolution text={solution} />
        </div>
      );
    }

    return (
      <div className="text-center p-8 text-slate-500 italic">
        {idleText}
      </div>
    );
  };

  return (
    <div className="bg-slate-800/50 rounded-xl shadow-lg border border-slate-700 min-h-[200px] flex items-center justify-center">
      {renderContent()}
    </div>
  );
};