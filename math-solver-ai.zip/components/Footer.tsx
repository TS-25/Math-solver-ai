import React from 'react';
import type { Language } from '../App';

interface FooterProps {
    language: Language;
}

export const Footer: React.FC<FooterProps> = ({ language }) => {
  const footerText = language === 'en'
    ? "Powered by Gemini. For educational purposes only."
    : "Gemini দ্বারা চালিত। শুধুমাত্র শিক্ষাগত উদ্দেশ্যে।";

  return (
    <footer className="py-4 mt-8">
      <div className="container mx-auto px-4 text-center text-sm text-slate-500">
        <p>{footerText}</p>
      </div>
    </footer>
  );
};