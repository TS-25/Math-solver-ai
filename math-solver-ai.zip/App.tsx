import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { InputArea } from './components/InputArea';
import { SolutionDisplay } from './components/SolutionDisplay';
import { ExampleProblems } from './components/ExampleProblems';
import { solveMathProblem } from './services/geminiService';
import { Footer } from './components/Footer';

export type Language = 'en' | 'bn';

const App: React.FC = () => {
  const [solution, setSolution] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [currentProblem, setCurrentProblem] = useState<string>('');
  const [language, setLanguage] = useState<Language>('en');

  const handleSolve = useCallback(async (problem: string) => {
    if (!problem.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setSolution('');
    setCurrentProblem(problem);

    try {
      const result = await solveMathProblem(problem, language);
      setSolution(result);
    } catch (err) {
      console.error(err);
      setError('An error occurred while solving the problem. Please check your API key and try again.');
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, language]);
  
  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    setSolution('');
    setError(null);
    setCurrentProblem('');
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 flex flex-col font-sans">
      <Header language={language} onLanguageChange={handleLanguageChange} />
      <main className="flex-grow container mx-auto px-4 py-8 flex flex-col items-center">
        <div className="w-full max-w-3xl space-y-8">
          <InputArea onSolve={handleSolve} isLoading={isLoading} language={language} />
          <ExampleProblems onSelectProblem={handleSolve} isLoading={isLoading} language={language}/>
          <SolutionDisplay 
            solution={solution} 
            isLoading={isLoading} 
            error={error} 
            problem={currentProblem}
            language={language}
          />
        </div>
      </main>
      <Footer language={language} />
    </div>
  );
};

export default App;